/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_363()
{
    return 3351742792U;
}

unsigned getval_290()
{
    return 3281017032U;
}

void setval_492(unsigned *p)
{
    *p = 3349760030U;
}

void setval_487(unsigned *p)
{
    *p = 2425411620U;
}

unsigned addval_355(unsigned x)
{
    return x + 2425394264U;
}

unsigned addval_306(unsigned x)
{
    return x + 3281031256U;
}

unsigned addval_445(unsigned x)
{
    return x + 3284633928U;
}

unsigned getval_226()
{
    return 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_342(unsigned x)
{
    return x + 2447411528U;
}

unsigned addval_413(unsigned x)
{
    return x + 3286272456U;
}

unsigned addval_449(unsigned x)
{
    return x + 2425536905U;
}

void setval_229(unsigned *p)
{
    *p = 3284847048U;
}

unsigned getval_224()
{
    return 3229931137U;
}

unsigned getval_307()
{
    return 3767093386U;
}

void setval_427(unsigned *p)
{
    *p = 3525888649U;
}

void setval_314(unsigned *p)
{
    *p = 3373848201U;
}

unsigned addval_356(unsigned x)
{
    return x + 3375417993U;
}

unsigned addval_158(unsigned x)
{
    return x + 3526937241U;
}

unsigned getval_402()
{
    return 3531920905U;
}

void setval_225(unsigned *p)
{
    *p = 3224945033U;
}

unsigned getval_497()
{
    return 3375421065U;
}

unsigned addval_375(unsigned x)
{
    return x + 4223779209U;
}

void setval_168(unsigned *p)
{
    *p = 3286272360U;
}

void setval_333(unsigned *p)
{
    *p = 3281049225U;
}

void setval_404(unsigned *p)
{
    *p = 1069796041U;
}

unsigned addval_496(unsigned x)
{
    return x + 3372794249U;
}

unsigned getval_146()
{
    return 2447411528U;
}

unsigned getval_222()
{
    return 3286272264U;
}

void setval_389(unsigned *p)
{
    *p = 2430635336U;
}

void setval_197(unsigned *p)
{
    *p = 2430634312U;
}

unsigned getval_477()
{
    return 3281046153U;
}

unsigned addval_145(unsigned x)
{
    return x + 2425536905U;
}

unsigned addval_396(unsigned x)
{
    return x + 3183990409U;
}

void setval_248(unsigned *p)
{
    *p = 2445969851U;
}

unsigned addval_460(unsigned x)
{
    return x + 3372269961U;
}

unsigned getval_199()
{
    return 3599305871U;
}

unsigned addval_236(unsigned x)
{
    return x + 3376993929U;
}

unsigned getval_269()
{
    return 3284241829U;
}

unsigned getval_463()
{
    return 2425405837U;
}

unsigned addval_186(unsigned x)
{
    return x + 3398005415U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
